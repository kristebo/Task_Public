// Generates a random API key and starts dev server with it.
// Prints the key so the user can copy it for requests.
import { spawn } from 'child_process';

function generateKey() {
  return 'dev-' + Math.random().toString(36).slice(2, 12) + '-' + Date.now().toString(36);
}

const key = generateKey();
console.log('\n[run-dev] Generated API key:', key);
console.log('[run-dev] Use this header: x-api-key: ' + key + '\n');

const child = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  env: { ...process.env, API_KEY: key },
});

child.on('exit', (code) => {
  console.log(`\n[run-dev] Dev process exited with code ${code}`);
});
