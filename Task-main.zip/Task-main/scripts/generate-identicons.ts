import fs from 'fs';
import path from 'path';

import { list } from '../src/data/flight/employeeStore';
import { generateIdenticonSvg } from '../src/utils/identicon';

async function main() {
  const employees = await list();
  const avatarDir = path.join(process.cwd(), 'data', 'avatars');
  if (!fs.existsSync(avatarDir)) fs.mkdirSync(avatarDir, { recursive: true });
  let written = 0;
  for (const e of employees) {
    const svgPath = path.join(avatarDir, `${e.id}.svg`);
    if (fs.existsSync(svgPath)) continue; // do not overwrite custom or existing
    const svg = generateIdenticonSvg(e.email || e.id);
    fs.writeFileSync(svgPath, svg, 'utf-8');
    written++;
  }
  console.log(`[identicons] Generated ${written} identicon(s) into data/avatars`);
}

main().catch((err) => {
  console.error('[identicons] Failed:', err);
  process.exit(1);
});
