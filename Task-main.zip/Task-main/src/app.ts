import cors from 'cors';
import express, { Request, Response } from 'express';
import morgan from 'morgan';
import swaggerUi from 'swagger-ui-express';

import { errorHandler, notFoundHandler } from './middleware/error';
import { apiKeyAuth, rateLimiter } from './middleware/security';
import { employeesRouter } from './routes/employees';
import { groupsRouter } from './routes/groups';
import { itinerariesRouter } from './routes/itineraries';
import { openApiSpec } from './swagger';

export const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Swagger UI
app.use('/docs', swaggerUi.serve, swaggerUi.setup(openApiSpec));

// Security middleware
app.use(rateLimiter);
app.use(apiKeyAuth);

// Domain routes
app.use('/api/employees', employeesRouter());
app.use('/api/itineraries', itinerariesRouter());
app.use('/api/groups', groupsRouter());

// 404 & error handlers
app.use(notFoundHandler);
app.use(errorHandler);
