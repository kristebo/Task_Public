import { z } from 'zod';

export const EmployeeSchema = z.object({
  id: z.string().min(1),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email(),
  department: z.string().min(1),
  title: z.string().min(1),
  active: z.boolean().default(true),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
export type Employee = z.infer<typeof EmployeeSchema>;

export const NewEmployeeSchema = EmployeeSchema.pick({
  firstName: true,
  lastName: true,
  email: true,
  department: true,
  title: true,
  active: true,
}).partial({ active: true });
export type NewEmployeeInput = z.infer<typeof NewEmployeeSchema>;

export const UpdateEmployeeSchema = NewEmployeeSchema.partial();
export type UpdateEmployeeInput = z.infer<typeof UpdateEmployeeSchema>;
