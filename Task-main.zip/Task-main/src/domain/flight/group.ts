import { z } from 'zod';

export const GroupSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(2),
  description: z.string().optional(),
  memberIds: z.array(z.string().min(1)).default([]),
  itineraryIds: z.array(z.string().min(1)).default([]),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
export type Group = z.infer<typeof GroupSchema>;

export const NewGroupSchema = GroupSchema.pick({
  name: true,
  description: true,
  memberIds: true,
  itineraryIds: true,
}).partial({ description: true, memberIds: true, itineraryIds: true });
export type NewGroupInput = z.infer<typeof NewGroupSchema>;

export const UpdateGroupSchema = NewGroupSchema.partial();
export type UpdateGroupInput = z.infer<typeof UpdateGroupSchema>;
