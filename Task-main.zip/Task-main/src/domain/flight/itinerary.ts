import { z } from 'zod';

export const FlightSegmentSchema = z.object({
  id: z.string().min(1),
  from: z.string().min(3).max(3), // IATA code
  to: z.string().min(3).max(3),
  departure: z.string().datetime(),
  arrival: z.string().datetime(),
  carrier: z.string().min(2),
  flightNumber: z.string().min(2),
  seatClass: z.enum(['economy', 'premium', 'business', 'first']).default('economy'),
});
export type FlightSegment = z.infer<typeof FlightSegmentSchema>;

export const TravelItinerarySchema = z.object({
  id: z.string().min(1),
  employeeId: z.string().min(1),
  purpose: z.string().min(3),
  status: z.enum(['draft', 'booked', 'traveling', 'completed', 'cancelled']).default('draft'),
  segments: z.array(FlightSegmentSchema),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
export type TravelItinerary = z.infer<typeof TravelItinerarySchema>;

export const NewSegmentSchema = FlightSegmentSchema.pick({
  from: true,
  to: true,
  departure: true,
  arrival: true,
  carrier: true,
  flightNumber: true,
  seatClass: true,
});
export const NewItinerarySchema = TravelItinerarySchema.pick({
  employeeId: true,
  purpose: true,
  status: true,
  segments: true,
})
  .partial({ status: true })
  .extend({
    segments: z.array(NewSegmentSchema).min(1),
  });
export type NewItineraryInput = z.infer<typeof NewItinerarySchema>;

export const UpdateItinerarySchema = NewItinerarySchema.partial();
export type UpdateItineraryInput = z.infer<typeof UpdateItinerarySchema>;
