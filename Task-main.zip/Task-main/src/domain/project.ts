import { z } from 'zod';

export const ProjectStatusSchema = z.enum(['planned', 'in-progress', 'completed', 'archived']);
export type ProjectStatus = z.infer<typeof ProjectStatusSchema>;

export const ProjectSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(2).max(120),
  description: z.string().max(2000).optional().default(''),
  status: ProjectStatusSchema.default('planned'),
  tags: z.array(z.string().min(1)).default([]),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});

export type Project = z.infer<typeof ProjectSchema>;

export const NewProjectSchema = ProjectSchema.pick({
  name: true,
  description: true,
  status: true,
  tags: true,
}).partial({ status: true, description: true, tags: true });
export type NewProjectInput = z.infer<typeof NewProjectSchema>;

export const UpdateProjectSchema = NewProjectSchema.partial();
export type UpdateProjectInput = z.infer<typeof UpdateProjectSchema>;
