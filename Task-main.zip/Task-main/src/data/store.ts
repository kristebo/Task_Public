import { promises as fs } from 'fs';
import path from 'path';

// Enkel ID-generator (base36 timestamp + counter) for å unngå ESM issues
let _counter = 0;
function genId() {
  _counter = (_counter + 1) % 10000;
  return (Date.now().toString(36) + _counter.toString(36)).slice(-10);
}
import { NewProjectInput, Project, ProjectSchema, UpdateProjectInput } from '../domain/project';

const DATA_FILE = path.resolve(__dirname, '../../data/projects.json');

async function ensureDataFile() {
  try {
    await fs.access(DATA_FILE);
  } catch {
    await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
    await fs.writeFile(DATA_FILE, '[]', 'utf-8');
  }
}

async function readAll(): Promise<Project[]> {
  await ensureDataFile();
  const raw = await fs.readFile(DATA_FILE, 'utf-8');
  const arr = JSON.parse(raw);
  return ProjectSchema.array().parse(arr);
}

async function writeAll(projects: Project[]) {
  await fs.writeFile(DATA_FILE, JSON.stringify(projects, null, 2), 'utf-8');
}

export async function list(filter?: { status?: string; tag?: string; search?: string }) {
  let projects = await readAll();
  if (filter?.status) projects = projects.filter((p) => p.status === filter.status);
  if (filter?.tag) projects = projects.filter((p) => p.tags.includes(filter.tag!));
  if (filter?.search) {
    const q = filter.search.toLowerCase();
    projects = projects.filter(
      (p) => p.name.toLowerCase().includes(q) || p.description?.toLowerCase().includes(q),
    );
  }
  return projects;
}

export async function get(id: string) {
  const projects = await readAll();
  return projects.find((p) => p.id === id) || null;
}

export async function create(input: NewProjectInput) {
  const now = new Date().toISOString();
  const project: Project = {
    id: genId(),
    name: input.name,
    description: input.description ?? '',
    status: (input.status as any) ?? 'planned',
    tags: input.tags ?? [],
    createdAt: now,
    updatedAt: now,
  };
  const projects = await readAll();
  projects.push(project);
  await writeAll(projects);
  return project;
}

export async function update(id: string, input: UpdateProjectInput) {
  const projects = await readAll();
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return null;
  const existing = projects[idx];
  const updated: Project = {
    ...existing,
    ...input,
    updatedAt: new Date().toISOString(),
  };
  projects[idx] = updated;
  await writeAll(projects);
  return updated;
}

export async function remove(id: string) {
  const projects = await readAll();
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return false;
  projects.splice(idx, 1);
  await writeAll(projects);
  return true;
}

export async function metrics() {
  const projects = await readAll();
  const total = projects.length;
  const byStatus = projects.reduce<Record<string, number>>((acc, p) => {
    acc[p.status] = (acc[p.status] || 0) + 1;
    return acc;
  }, {});
  return { total, byStatus };
}
