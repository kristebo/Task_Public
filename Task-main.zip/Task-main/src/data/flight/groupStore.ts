import { promises as fs } from 'fs';
import path from 'path';

import { Group, GroupSchema, NewGroupInput, UpdateGroupInput } from '../../domain/flight/group';

import { get as getEmployee } from './employeeStore';
import { get as getItinerary } from './itineraryStore';

const DATA_FILE = path.resolve(process.cwd(), 'data/groups.json');
function genId() {
  return Math.random().toString(36).slice(2, 10);
}

async function ensureFile() {
  try {
    await fs.access(DATA_FILE);
  } catch {
    await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
    await fs.writeFile(DATA_FILE, '[]');
  }
}
let cache: Group[] | null = null;
async function readAll(): Promise<Group[]> {
  if (cache) return cache;
  await ensureFile();
  const raw = await fs.readFile(DATA_FILE, 'utf-8');
  cache = GroupSchema.array().parse(JSON.parse(raw));
  return cache;
}
async function writeAll(list: Group[]) {
  cache = list;
  await fs.writeFile(DATA_FILE, JSON.stringify(list, null, 2));
}

export async function list() {
  return readAll();
}
export async function get(id: string) {
  const all = await readAll();
  return all.find((g) => g.id === id) || null;
}
export async function create(input: NewGroupInput) {
  const now = new Date().toISOString();
  const memberIds = input.memberIds ?? [];
  for (const m of memberIds) {
    if (!(await getEmployee(m)))
      throw Object.assign(new Error(`Member ${m} not found`), { status: 400 });
  }
  const itineraryIds = input.itineraryIds ?? [];
  for (const it of itineraryIds) {
    if (!(await getItinerary(it)))
      throw Object.assign(new Error(`Itinerary ${it} not found`), { status: 400 });
  }
  const entity: Group = {
    id: genId(),
    name: input.name,
    description: input.description,
    memberIds,
    itineraryIds,
    createdAt: now,
    updatedAt: now,
  };
  const all = await readAll();
  all.push(entity);
  await writeAll(all);
  return entity;
}
export async function update(id: string, input: UpdateGroupInput) {
  const all = await readAll();
  const idx = all.findIndex((g) => g.id === id);
  if (idx === -1) return null;
  if (input.memberIds) {
    for (const m of input.memberIds) {
      if (!(await getEmployee(m)))
        throw Object.assign(new Error(`Member ${m} not found`), { status: 400 });
    }
  }
  if (input.itineraryIds) {
    for (const it of input.itineraryIds) {
      if (!(await getItinerary(it)))
        throw Object.assign(new Error(`Itinerary ${it} not found`), { status: 400 });
    }
  }
  const now = new Date().toISOString();
  const updated: Group = { ...all[idx], ...input, updatedAt: now };
  all[idx] = updated;
  await writeAll(all);
  return updated;
}
export async function remove(id: string) {
  const all = await readAll();
  const idx = all.findIndex((g) => g.id === id);
  if (idx === -1) return false;
  all.splice(idx, 1);
  await writeAll(all);
  return true;
}
