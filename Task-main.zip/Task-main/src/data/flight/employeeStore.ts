import { promises as fs } from 'fs';
import path from 'path';

import {
  Employee,
  EmployeeSchema,
  NewEmployeeInput,
  UpdateEmployeeInput,
} from '../../domain/flight/employee';

const DATA_FILE = path.resolve(process.cwd(), 'data/employees.json');

function genId() {
  return Math.random().toString(36).slice(2, 10);
}

async function ensureFile() {
  try {
    await fs.access(DATA_FILE);
  } catch {
    await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
    await fs.writeFile(DATA_FILE, '[]');
  }
}
async function readAll(): Promise<Employee[]> {
  await ensureFile();
  const raw = await fs.readFile(DATA_FILE, 'utf-8');
  return EmployeeSchema.array().parse(JSON.parse(raw));
}
async function writeAll(list: Employee[]) {
  await fs.writeFile(DATA_FILE, JSON.stringify(list, null, 2));
}

export async function list() {
  return readAll();
}
export async function get(id: string) {
  const all = await readAll();
  return all.find((e) => e.id === id) || null;
}
export async function create(input: NewEmployeeInput) {
  const now = new Date().toISOString();
  const employee: Employee = {
    id: genId(),
    firstName: input.firstName,
    lastName: input.lastName,
    email: input.email,
    department: input.department,
    title: input.title,
    active: input.active ?? true,
    createdAt: now,
    updatedAt: now,
  };
  const all = await readAll();
  all.push(employee);
  await writeAll(all);
  return employee;
}
export async function update(id: string, input: UpdateEmployeeInput) {
  const all = await readAll();
  const idx = all.findIndex((e) => e.id === id);
  if (idx === -1) return null;
  const now = new Date().toISOString();
  const updated: Employee = { ...all[idx], ...input, updatedAt: now };
  all[idx] = updated;
  await writeAll(all);
  return updated;
}
export async function remove(id: string) {
  const all = await readAll();
  const idx = all.findIndex((e) => e.id === id);
  if (idx === -1) return false;
  all.splice(idx, 1);
  await writeAll(all);
  return true;
}
