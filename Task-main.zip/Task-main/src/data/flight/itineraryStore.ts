import { promises as fs } from 'fs';
import path from 'path';

import {
  TravelItinerary,
  TravelItinerarySchema,
  NewItineraryInput,
  UpdateItineraryInput,
  FlightSegment,
  NewSegmentSchema,
} from '../../domain/flight/itinerary';

import { get as getEmployee } from './employeeStore';

const DATA_FILE = path.resolve(process.cwd(), 'data/itineraries.json');

function genId() {
  return Math.random().toString(36).slice(2, 10);
}

async function ensureFile() {
  try {
    await fs.access(DATA_FILE);
  } catch {
    await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
    await fs.writeFile(DATA_FILE, '[]');
  }
}
let cache: TravelItinerary[] | null = null;
async function readAll(): Promise<TravelItinerary[]> {
  if (cache) return cache;
  await ensureFile();
  const raw = await fs.readFile(DATA_FILE, 'utf-8');
  cache = TravelItinerarySchema.array().parse(JSON.parse(raw));
  return cache;
}
async function writeAll(list: TravelItinerary[]) {
  cache = list;
  await fs.writeFile(DATA_FILE, JSON.stringify(list, null, 2));
}

export async function list(filter?: { employeeId?: string; status?: string }) {
  let all = await readAll();
  if (filter?.employeeId) all = all.filter((i) => i.employeeId === filter.employeeId);
  if (filter?.status) all = all.filter((i) => i.status === filter.status);
  return all;
}
export async function get(id: string) {
  const all = await readAll();
  return all.find((i) => i.id === id) || null;
}
export async function create(input: NewItineraryInput) {
  const emp = await getEmployee(input.employeeId);
  if (!emp) throw Object.assign(new Error('Employee not found'), { status: 400 });
  const now = new Date().toISOString();
  const segments: FlightSegment[] = input.segments.map((s) => ({ id: genId(), ...s }));
  segments.forEach((seg) => NewSegmentSchema.parse({ ...seg }));
  const entity: TravelItinerary = {
    id: genId(),
    employeeId: input.employeeId,
    purpose: input.purpose,
    status: (input.status as any) ?? 'draft',
    segments,
    createdAt: now,
    updatedAt: now,
  };
  const all = await readAll();
  all.push(entity);
  await writeAll(all);
  return entity;
}
export async function update(id: string, input: UpdateItineraryInput) {
  const all = await readAll();
  const idx = all.findIndex((i) => i.id === id);
  if (idx === -1) return null;
  if (input.employeeId && !(await getEmployee(input.employeeId)))
    throw Object.assign(new Error('Employee not found'), { status: 400 });
  const now = new Date().toISOString();
  const existing = all[idx];
  const updated: TravelItinerary = {
    ...existing,
    ...input,
    segments: input.segments
      ? input.segments.map((s) => ({ id: genId(), ...s }))
      : existing.segments,
    updatedAt: now,
  };
  all[idx] = updated;
  await writeAll(all);
  return updated;
}
export async function remove(id: string) {
  const all = await readAll();
  const idx = all.findIndex((i) => i.id === id);
  if (idx === -1) return false;
  all.splice(idx, 1);
  await writeAll(all);
  return true;
}
