export const API_KEY = process.env.API_KEY || 'dev-key';
export const RATE_LIMIT_WINDOW_MS = 60_000; // 1 minutt
export const RATE_LIMIT_MAX = 100; // requests pr IP per vindu
