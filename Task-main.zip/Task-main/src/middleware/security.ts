import { Request, Response, NextFunction } from 'express';

import { API_KEY, RATE_LIMIT_MAX, RATE_LIMIT_WINDOW_MS } from '../config';

// Enkel IP-baserte teller (ikke for produksjon)
interface Counter {
  count: number;
  resetAt: number;
}
const buckets = new Map<string, Counter>();

export function rateLimiter(req: Request, res: Response, next: NextFunction) {
  // Skip for health & docs
  if (req.path.startsWith('/health') || req.path.startsWith('/docs')) return next();
  const ip = req.ip || 'unknown';
  const now = Date.now();
  let bucket = buckets.get(ip);
  if (!bucket || bucket.resetAt < now) {
    bucket = { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS };
    buckets.set(ip, bucket);
  }
  bucket.count += 1;
  if (bucket.count > RATE_LIMIT_MAX) {
    return res.status(429).json({
      error: {
        code: 'RATE_LIMIT',
        message: 'Too many requests',
        retryAfterMs: bucket.resetAt - now,
      },
    });
  }
  res.setHeader('X-RateLimit-Limit', RATE_LIMIT_MAX.toString());
  res.setHeader('X-RateLimit-Remaining', String(Math.max(RATE_LIMIT_MAX - bucket.count, 0)));
  res.setHeader('X-RateLimit-Reset', new Date(bucket.resetAt).toISOString());
  next();
}

export function apiKeyAuth(req: Request, res: Response, next: NextFunction) {
  // Public (unauthenticated) endpoints:
  // - /health
  // - /docs (swagger ui)
  // - GET /api/employees/:id/avatar (serve avatar images so <img> tags work without custom headers)
  if (req.path.startsWith('/health') || req.path.startsWith('/docs')) return next();
  if (req.method === 'GET' && /\/api\/employees\/[^/]+\/avatar$/.test(req.path)) return next();
  const key = req.header('x-api-key');
  if (!key || key !== API_KEY) {
    return res.status(401).json({
      error: { code: 'UNAUTHORIZED', message: 'Missing or invalid API key' },
    });
  }
  next();
}
