import { AxiosError } from 'axios';
import { Request, Response, NextFunction } from 'express';

export function notFoundHandler(_req: Request, res: Response) {
  res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Resource not found' } });
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (res.headersSent) return;
  const anyErr = err as any;
  const status: number = typeof anyErr?.status === 'number' ? anyErr.status : 500;
  const code: string =
    typeof anyErr?.code === 'string' ? anyErr.code : status === 500 ? 'INTERNAL_ERROR' : 'ERROR';
  const payload: { error: { code: string; message: string; details?: unknown } } = {
    error: { code, message: anyErr?.message || 'Unexpected error' },
  };
  if (anyErr?.code && (anyErr as AxiosError).response?.data) {
    payload.error.details = (anyErr as AxiosError).response?.data;
  }
  res.status(status).json(payload);
}
