import { Router } from 'express';

import * as groupStore from '../data/flight/groupStore';
import { NewGroupSchema, UpdateGroupSchema } from '../domain/flight/group';

export function groupsRouter() {
  const r = Router();
  r.get('/', async (_req, res, next) => {
    try {
      res.json(await groupStore.list());
    } catch (e) {
      next(e);
    }
  });
  r.get('/:id', async (req, res, next) => {
    try {
      const v = await groupStore.get(req.params.id);
      if (!v)
        return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Group not found' } });
      res.json(v);
    } catch (e) {
      next(e);
    }
  });
  r.post('/', async (req, res, next) => {
    try {
      const p = NewGroupSchema.safeParse(req.body);
      if (!p.success)
        return res.status(400).json({
          error: { code: 'VALIDATION', message: 'Validation failed', details: p.error.issues },
        });
      const created = await groupStore.create(p.data);
      res.status(201).json(created);
    } catch (e) {
      const err = e as { status?: number; message?: string };
      if (err.status === 400)
        return res.status(400).json({ error: { code: 'REF_INTEGRITY', message: err.message || 'Referential integrity' } });
      next(err as any);
    }
  });
  r.patch('/:id', async (req, res, next) => {
    try {
      const p = UpdateGroupSchema.safeParse(req.body);
      if (!p.success)
        return res.status(400).json({
          error: { code: 'VALIDATION', message: 'Validation failed', details: p.error.issues },
        });
      const updated = await groupStore.update(req.params.id, p.data);
      if (!updated)
        return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Group not found' } });
      res.json(updated);
    } catch (e) {
      const err = e as { status?: number; message?: string };
      if (err.status === 400)
        return res.status(400).json({ error: { code: 'REF_INTEGRITY', message: err.message || 'Referential integrity' } });
      next(err as any);
    }
  });
  r.delete('/:id', async (req, res, next) => {
    try {
      const ok = await groupStore.remove(req.params.id);
      if (!ok)
        return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Group not found' } });
      res.status(204).send();
    } catch (e) {
      next(e);
    }
  });
  return r;
}
