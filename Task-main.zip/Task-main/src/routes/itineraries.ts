import { Router } from 'express';

import * as itineraryStore from '../data/flight/itineraryStore';
import { NewItinerarySchema, UpdateItinerarySchema } from '../domain/flight/itinerary';

export function itinerariesRouter() {
  const r = Router();
  r.get('/', async (req, res, next) => {
    try {
      const { employeeId, status } = req.query;
      const list = await itineraryStore.list({
        employeeId: employeeId as string | undefined,
        status: status as string | undefined,
      });
      res.json(list);
    } catch (e) {
      next(e);
    }
  });
  r.get('/:id', async (req, res, next) => {
    try {
      const v = await itineraryStore.get(req.params.id);
      if (!v)
        return res
          .status(404)
          .json({ error: { code: 'NOT_FOUND', message: 'Itinerary not found' } });
      res.json(v);
    } catch (e) {
      next(e);
    }
  });
  r.post('/', async (req, res, next) => {
    try {
      const p = NewItinerarySchema.safeParse(req.body);
      if (!p.success)
        return res.status(400).json({
          error: { code: 'VALIDATION', message: 'Validation failed', details: p.error.issues },
        });
      const created = await itineraryStore.create(p.data);
      res.status(201).json(created);
    } catch (e) {
      const err = e as { status?: number; message?: string };
      if (err.status === 400)
        return res
          .status(400)
          .json({
            error: { code: 'REF_INTEGRITY', message: err.message || 'Referential integrity' },
          });
      next(err as any);
    }
  });
  r.patch('/:id', async (req, res, next) => {
    try {
      const p = UpdateItinerarySchema.safeParse(req.body);
      if (!p.success)
        return res.status(400).json({
          error: { code: 'VALIDATION', message: 'Validation failed', details: p.error.issues },
        });
      const updated = await itineraryStore.update(req.params.id, p.data);
      if (!updated)
        return res
          .status(404)
          .json({ error: { code: 'NOT_FOUND', message: 'Itinerary not found' } });
      res.json(updated);
    } catch (e) {
      const err = e as { status?: number; message?: string };
      if (err.status === 400)
        return res
          .status(400)
          .json({
            error: { code: 'REF_INTEGRITY', message: err.message || 'Referential integrity' },
          });
      next(err as any);
    }
  });
  r.delete('/:id', async (req, res, next) => {
    try {
      const ok = await itineraryStore.remove(req.params.id);
      if (!ok)
        return res
          .status(404)
          .json({ error: { code: 'NOT_FOUND', message: 'Itinerary not found' } });
      res.status(204).send();
    } catch (e) {
      next(e);
    }
  });
  return r;
}
