import fs from 'fs';
import path from 'path';

import { Router } from 'express';
import multer from 'multer';

import * as employeeStore from '../data/flight/employeeStore';
import { NewEmployeeSchema, UpdateEmployeeSchema } from '../domain/flight/employee';
import { generateIdenticonSvg } from '../utils/identicon';

export function employeesRouter() {
  const r = Router();
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 2 * 1024 * 1024 },
  });
  const avatarDir = path.join(process.cwd(), 'data', 'avatars');
  if (!fs.existsSync(avatarDir)) fs.mkdirSync(avatarDir, { recursive: true });

  r.get('/', async (_req, res, next) => {
    try {
      res.json(await employeeStore.list());
    } catch (e) {
      next(e);
    }
  });
  r.get('/:id', async (req, res, next) => {
    try {
      const v = await employeeStore.get(req.params.id);
      if (!v)
        return res.status(404).json({
          error: { code: 'NOT_FOUND', message: 'Employee not found' },
        });
      res.json(v);
    } catch (e) {
      next(e);
    }
  });
  r.post('/', async (req, res, next) => {
    try {
      const p = NewEmployeeSchema.safeParse(req.body);
      if (!p.success)
        return res.status(400).json({
          error: {
            code: 'VALIDATION',
            message: 'Validation failed',
            details: p.error.issues,
          },
        });
      const created = await employeeStore.create(p.data);
      res.status(201).json(created);
    } catch (e) {
      next(e);
    }
  });
  r.patch('/:id', async (req, res, next) => {
    try {
      const p = UpdateEmployeeSchema.safeParse(req.body);
      if (!p.success)
        return res.status(400).json({
          error: {
            code: 'VALIDATION',
            message: 'Validation failed',
            details: p.error.issues,
          },
        });
      const updated = await employeeStore.update(req.params.id, p.data);
      if (!updated)
        return res.status(404).json({
          error: { code: 'NOT_FOUND', message: 'Employee not found' },
        });
      res.json(updated);
    } catch (e) {
      next(e);
    }
  });
  r.delete('/:id', async (req, res, next) => {
    try {
      const ok = await employeeStore.remove(req.params.id);
      if (!ok)
        return res.status(404).json({
          error: { code: 'NOT_FOUND', message: 'Employee not found' },
        });
      res.status(204).send();
    } catch (e) {
      next(e);
    }
  });

  // GET avatar (custom uploaded file if exists, else identicon SVG)
  r.get('/:id/avatar', async (req, res, next) => {
    try {
      const emp = await employeeStore.get(req.params.id);
      if (!emp)
        return res.status(404).json({
          error: { code: 'NOT_FOUND', message: 'Employee not found' },
        });
      const filePathBase = path.join(avatarDir, req.params.id);
      const pngPath = filePathBase + '.png';
      const jpgPath = filePathBase + '.jpg';
      const webpPath = filePathBase + '.webp';
      const svgPath = filePathBase + '.svg';
      const existing = [pngPath, jpgPath, webpPath, svgPath].find((p) => fs.existsSync(p));
      if (existing) {
        return res.sendFile(existing);
      }
      const svg = generateIdenticonSvg(emp.email || emp.id);
      res.setHeader('Content-Type', 'image/svg+xml');
      res.send(svg);
    } catch (e) {
      next(e);
    }
  });

  // Upload custom avatar
  r.post('/:id/avatar', upload.single('file'), async (req, res, next) => {
    try {
      const emp = await employeeStore.get(req.params.id);
      if (!emp)
        return res.status(404).json({
          error: { code: 'NOT_FOUND', message: 'Employee not found' },
        });
      if (!req.file)
        return res.status(400).json({ error: { code: 'VALIDATION', message: 'No file uploaded' } });
      // basic mime check
      const allowed = ['image/png', 'image/jpeg', 'image/webp'];
      if (!allowed.includes(req.file.mimetype)) {
        return res.status(400).json({
          error: { code: 'VALIDATION', message: 'Unsupported file type' },
        });
      }
      const ext =
        req.file.mimetype === 'image/png'
          ? 'png'
          : req.file.mimetype === 'image/webp'
            ? 'webp'
            : 'jpg';
      const dest = path.join(avatarDir, `${req.params.id}.${ext}`);
      // remove other formats for this user
      ['png', 'jpg', 'webp'].forEach((e) => {
        const p = path.join(avatarDir, `${req.params.id}.${e}`);
        if (fs.existsSync(p) && p !== dest) fs.unlinkSync(p);
      });
      fs.writeFileSync(dest, req.file.buffer);
      res.status(201).json({
        message: 'Avatar uploaded',
        path: `/api/employees/${req.params.id}/avatar`,
      });
    } catch (e) {
      next(e);
    }
  });
  return r;
}
