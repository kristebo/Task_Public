import request from 'supertest';

import { app, API_KEY, resetAll, createEmployee } from './helpers';

describe('Employees API', () => {
  beforeEach(async () => {
    await resetAll();
  });

  test('rejects without API key', async () => {
    const res = await request(app).get('/api/employees');
    expect(res.status).toBe(401);
    expect(res.body.error?.code).toBe('UNAUTHORIZED');
  });

  test('create + list + get employee', async () => {
    const create = await request(app).post('/api/employees').set('x-api-key', API_KEY).send({
      firstName: 'Ada',
      lastName: 'Lovelace',
      email: 'ada@example.com',
      department: 'Engineering',
      title: 'Pioneer',
    });
    expect(create.status).toBe(201);
    const emp = create.body;
    expect(emp.id).toBeDefined();

    const list = await request(app).get('/api/employees').set('x-api-key', API_KEY);
    expect(list.status).toBe(200);
    expect(list.body.length).toBe(1);

    const get = await request(app).get(`/api/employees/${emp.id}`).set('x-api-key', API_KEY);
    expect(get.status).toBe(200);
    expect(get.body.email).toBe('ada@example.com');
  });

  test('validation error on create', async () => {
    const res = await request(app)
      .post('/api/employees')
      .set('x-api-key', API_KEY)
      .send({ firstName: '' });
    expect(res.status).toBe(400);
    expect(res.body.error?.code).toBe('VALIDATION');
  });

  test('update and delete flow', async () => {
    const create = await request(app).post('/api/employees').set('x-api-key', API_KEY).send({
      firstName: 'Linus',
      lastName: 'Torvalds',
      email: 'linus@example.com',
      department: 'Engineering',
      title: 'Architect',
    });
    const id = create.body.id;
    const patch = await request(app)
      .patch(`/api/employees/${id}`)
      .set('x-api-key', API_KEY)
      .send({ active: false });
    expect(patch.status).toBe(200);
    expect(patch.body.active).toBe(false);

    const del = await request(app).delete(`/api/employees/${id}`).set('x-api-key', API_KEY);
    expect(del.status).toBe(204);

    const getAfter = await request(app).get(`/api/employees/${id}`).set('x-api-key', API_KEY);
    expect(getAfter.status).toBe(404);
  });
});
