import request from 'supertest';

import { app, API_KEY, resetAll, createEmployee, createItinerary } from './helpers';

describe('Groups API', () => {
  beforeEach(async () => {
    await resetAll();
  });

  test('create group with members and itinerary', async () => {
    const empId = (await createEmployee()).id;
    const itId = (await createItinerary(empId)).id;
    const create = await request(app)
      .post('/api/groups')
      .set('x-api-key', API_KEY)
      .send({
        name: 'Team A',
        memberIds: [empId],
        itineraryIds: [itId],
      });
    expect(create.status).toBe(201);
    expect(create.body.memberIds.length).toBe(1);
    expect(create.body.itineraryIds[0]).toBe(itId);
  });

  test('reject group with unknown member', async () => {
    const create = await request(app)
      .post('/api/groups')
      .set('x-api-key', API_KEY)
      .send({
        name: 'Broken',
        memberIds: ['missing'],
      });
    expect(create.status).toBe(400);
    expect(create.body.error?.code).toBe('REF_INTEGRITY');
  });

  test('update group add member', async () => {
    const emp1 = await createEmployee();
    const emp2 = await createEmployee();
    const create = await request(app)
      .post('/api/groups')
      .set('x-api-key', API_KEY)
      .send({ name: 'Core', memberIds: [emp1.id] });
    expect(create.status).toBe(201);
    const id = create.body.id as string;
    const patch = await request(app)
      .patch(`/api/groups/${id}`)
      .set('x-api-key', API_KEY)
      .send({ memberIds: [emp1.id, emp2.id] });
    expect(patch.status).toBe(200);
    expect(patch.body.memberIds.length).toBe(2);
  });
});
