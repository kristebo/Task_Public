import { promises as fs } from 'fs';
import path from 'path';

import request from 'supertest';

import { app } from '../app';

export const API_KEY = 'dev-key';

const dataDir = path.resolve(process.cwd(), 'data');
const employeesFile = path.join(dataDir, 'employees.json');
const itinerariesFile = path.join(dataDir, 'itineraries.json');
const groupsFile = path.join(dataDir, 'groups.json');

export async function resetAll() {
  await fs.mkdir(dataDir, { recursive: true });
  await Promise.all([
    fs.writeFile(employeesFile, '[]', 'utf-8'),
    fs.writeFile(itinerariesFile, '[]', 'utf-8'),
    fs.writeFile(groupsFile, '[]', 'utf-8'),
  ]);
}

export async function createEmployee(overrides: Partial<Record<string, any>> = {}) {
  const base = {
    firstName: 'Test',
    lastName: 'User',
    email: `t${Math.random().toString(36).slice(2, 8)}@example.com`,
    department: 'Ops',
    title: 'Agent',
  };
  const res = await request(app)
    .post('/api/employees')
    .set('x-api-key', API_KEY)
    .send({ ...base, ...overrides });
  return res.body; // includes id
}

export async function createItinerary(
  employeeId: string,
  overrides: Partial<Record<string, any>> = {},
) {
  const base = {
    employeeId,
    purpose: 'Trip',
    segments: [
      {
        from: 'OSL',
        to: 'ARN',
        departure: '2025-05-01T08:00:00Z',
        arrival: '2025-05-01T09:00:00Z',
        carrier: 'SK',
        flightNumber: 'SK123',
        seatClass: 'economy',
      },
    ],
  };
  const res = await request(app)
    .post('/api/itineraries')
    .set('x-api-key', API_KEY)
    .send({ ...base, ...overrides });
  return res.body;
}

export async function createGroup(data: Partial<Record<string, any>>) {
  const res = await request(app).post('/api/groups').set('x-api-key', API_KEY).send(data);
  return res.body;
}

export { app };
