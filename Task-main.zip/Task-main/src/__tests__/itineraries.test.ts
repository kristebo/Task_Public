import request from 'supertest';

import { app, API_KEY, resetAll, createEmployee } from './helpers';

describe('Itineraries API', () => {
  beforeEach(async () => {
    await resetAll();
  });

  // createEmployee imported from helpers returns full body

  test('create itinerary for employee', async () => {
    const emp = await createEmployee();
    const empId = emp.id;
    const create = await request(app)
      .post('/api/itineraries')
      .set('x-api-key', API_KEY)
      .send({
        employeeId: empId,
        purpose: 'Conference',
        segments: [
          {
            from: 'OSL',
            to: 'ARN',
            departure: '2025-05-01T08:00:00Z',
            arrival: '2025-05-01T09:00:00Z',
            carrier: 'SK',
            flightNumber: 'SK123',
            seatClass: 'economy',
          },
        ],
      });
    expect(create.status).toBe(201);
    expect(create.body.segments.length).toBe(1);

    const list = await request(app)
      .get('/api/itineraries')
      .set('x-api-key', API_KEY)
      .query({ employeeId: empId });
    expect(list.status).toBe(200);
    expect(list.body.length).toBe(1);
  });

  test('reject itinerary with unknown employee (referential integrity)', async () => {
    const create = await request(app)
      .post('/api/itineraries')
      .set('x-api-key', API_KEY)
      .send({
        employeeId: 'nope',
        purpose: 'Trip',
        segments: [
          {
            from: 'OSL',
            to: 'CPH',
            departure: '2025-06-01T08:00:00Z',
            arrival: '2025-06-01T09:00:00Z',
            carrier: 'SK',
            flightNumber: 'SK555',
            seatClass: 'economy',
          },
        ],
      });
    expect(create.status).toBe(400);
    expect(create.body.error?.code).toBe('REF_INTEGRITY');
  });

  test('update itinerary status', async () => {
    const empId = (await createEmployee()).id;
    const create = await request(app)
      .post('/api/itineraries')
      .set('x-api-key', API_KEY)
      .send({
        employeeId: empId,
        purpose: 'Sales',
        segments: [
          {
            from: 'OSL',
            to: 'LHR',
            departure: '2025-07-01T06:00:00Z',
            arrival: '2025-07-01T08:00:00Z',
            carrier: 'BA',
            flightNumber: 'BA761',
            seatClass: 'economy',
          },
        ],
      });
    const id = create.body.id;
    const patch = await request(app)
      .patch(`/api/itineraries/${id}`)
      .set('x-api-key', API_KEY)
      .send({ status: 'booked' });
    expect(patch.status).toBe(200);
    expect(patch.body.status).toBe('booked');
  });
});
