// Legacy domain (projects) removed. Keeping a skipped test so Jest does not fail if pattern still matches.
test.skip('legacy projects domain (removed)', () => {}); /**
 * Legacy Projects-domain er fjernet. Denne placeholder-testen finnes kun
 * for å dokumentere at domenet ble erstattet av Flight Planner.
 */
describe.skip('legacy projects domain removed', () => {
  it('placeholder', () => {
    expect(true).toBe(true);
  });
});
