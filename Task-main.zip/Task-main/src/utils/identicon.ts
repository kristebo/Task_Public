import crypto from 'crypto';

// Lightweight deterministic identicon SVG generator (GitHub-like inspired)
// Not pixel-perfect to GitHub, but conveys unique color + block pattern.
export function generateIdenticonSvg(seed: string, size = 5, scale = 40) {
  const hash = crypto.createHash('sha256').update(seed).digest('hex');
  // First 6 bytes for base color
  const r = parseInt(hash.slice(0, 2), 16);
  const g = parseInt(hash.slice(2, 4), 16);
  const b = parseInt(hash.slice(4, 6), 16);
  const base = `rgb(${r},${g},${b})`;
  // Derive a lighter background
  const bg = `rgb(${255 - r / 4},${255 - g / 4},${255 - b / 4})`;
  // Remaining hash bits decide which squares to fill
  const cells: boolean[][] = [];
  let ptr = 6; // start after color bytes
  for (let y = 0; y < size; y++) {
    const row: boolean[] = [];
    for (let x = 0; x < Math.ceil(size / 2); x++) {
      // Use one nibble per cell
      if (ptr >= hash.length) ptr = 6; // wrap if needed
      const nibble = parseInt(hash[ptr], 16);
      ptr++;
      row.push(nibble % 2 === 0);
    }
    // Mirror row for symmetry
    const mirror = row.slice(0, size - row.length).reverse();
    cells.push([...row, ...mirror]);
  }
  const svgParts: string[] = [];
  svgParts.push(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${size * scale}" height="${size * scale}" viewBox="0 0 ${size} ${size}" shape-rendering="crispEdges" role="img" aria-label="identicon">`,
  );
  svgParts.push(`<rect width="${size}" height="${size}" fill="${bg}"/>`);
  cells.forEach((row, y) => {
    row.forEach((on, x) => {
      if (on) {
        const cellColor = shade(base, ((x + y) % 5) * 4 - 8);
        svgParts.push(`<rect x="${x}" y="${y}" width="1" height="1" fill="${cellColor}"/>`);
      }
    });
  });
  svgParts.push('</svg>');
  return svgParts.join('');
}

function shade(rgb: string, percent: number) {
  const m = /rgb\((\d+),(\d+),(\d+)\)/.exec(rgb);
  if (!m) return rgb;
  const [r, g, b] = m.slice(1).map(Number);
  const f = (v: number) => Math.min(255, Math.max(0, Math.round(v + (percent / 100) * 255)));
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
