import { OpenAPIV3 } from 'openapi-types';

export const openApiSpec: OpenAPIV3.Document = {
  openapi: '3.0.3',
  info: {
    title: 'Flight Planner API',
    version: '1.0.0',
    description: 'Internal flight planning backend for candidate exercise.',
  },
  servers: [{ url: 'http://localhost:3000', description: 'Local dev' }],
  tags: [
    { name: 'Health' },
    { name: 'Employees', description: 'Manage employees' },
    { name: 'Itineraries', description: 'Manage travel itineraries and flight segments' },
    { name: 'Groups', description: 'Manage travel groups' },
  ],
  components: {
    securitySchemes: {
      ApiKeyAuth: {
        type: 'apiKey',
        in: 'header',
        name: 'x-api-key',
      },
    },
    schemas: {
      Error: {
        type: 'object',
        required: ['error'],
        properties: {
          error: {
            type: 'object',
            required: ['code', 'message'],
            properties: {
              code: { type: 'string', example: 'VALIDATION' },
              message: { type: 'string', example: 'Validation failed' },
              details: { type: 'array', items: { type: 'object' } },
            },
          },
        },
      },
      Employee: {
        type: 'object',
        required: [
          'id',
          'firstName',
          'lastName',
          'email',
          'department',
          'title',
          'active',
          'createdAt',
          'updatedAt',
        ],
        properties: {
          id: { type: 'string' },
          firstName: { type: 'string' },
          lastName: { type: 'string' },
          email: { type: 'string', format: 'email' },
          department: { type: 'string', example: 'Engineering' },
          title: { type: 'string' },
          active: { type: 'boolean' },
          createdAt: { type: 'string', format: 'date-time' },
          updatedAt: { type: 'string', format: 'date-time' },
          avatarUrl: {
            type: 'string',
            nullable: true,
            description: 'URL to avatar (custom upload or generated identicon endpoint)',
          },
        },
      },
      NewEmployee: {
        type: 'object',
        required: ['firstName', 'lastName', 'email', 'department', 'title'],
        properties: {
          firstName: { type: 'string' },
          lastName: { type: 'string' },
          email: { type: 'string', format: 'email' },
          department: { type: 'string' },
          title: { type: 'string' },
          active: { type: 'boolean' },
        },
      },
      UpdateEmployee: {
        allOf: [{ $ref: '#/components/schemas/NewEmployee' }],
      },
      FlightSegment: {
        type: 'object',
        required: [
          'id',
          'from',
          'to',
          'departure',
          'arrival',
          'carrier',
          'flightNumber',
          'seatClass',
        ],
        properties: {
          id: { type: 'string' },
          from: { type: 'string', minLength: 3, maxLength: 3, example: 'OSL' },
          to: { type: 'string', minLength: 3, maxLength: 3, example: 'LHR' },
          departure: { type: 'string', format: 'date-time' },
          arrival: { type: 'string', format: 'date-time' },
          carrier: { type: 'string', example: 'SK' },
          flightNumber: { type: 'string', example: 'SK123' },
          seatClass: { type: 'string', enum: ['economy', 'premium', 'business', 'first'] },
        },
      },
      NewFlightSegment: {
        type: 'object',
        required: ['from', 'to', 'departure', 'arrival', 'carrier', 'flightNumber', 'seatClass'],
        properties: {
          from: { type: 'string', example: 'OSL' },
          to: { type: 'string', example: 'ARN' },
          departure: { type: 'string', format: 'date-time' },
          arrival: { type: 'string', format: 'date-time' },
          carrier: { type: 'string' },
          flightNumber: { type: 'string' },
          seatClass: { type: 'string', enum: ['economy', 'premium', 'business', 'first'] },
        },
      },
      TravelItinerary: {
        type: 'object',
        required: ['id', 'employeeId', 'purpose', 'status', 'segments', 'createdAt', 'updatedAt'],
        properties: {
          id: { type: 'string' },
          employeeId: { type: 'string' },
          purpose: { type: 'string' },
          status: {
            type: 'string',
            enum: ['draft', 'booked', 'traveling', 'completed', 'cancelled'],
          },
          segments: { type: 'array', items: { $ref: '#/components/schemas/FlightSegment' } },
          createdAt: { type: 'string', format: 'date-time' },
          updatedAt: { type: 'string', format: 'date-time' },
        },
      },
      NewTravelItinerary: {
        type: 'object',
        required: ['employeeId', 'purpose', 'segments'],
        properties: {
          employeeId: { type: 'string' },
          purpose: { type: 'string' },
          status: {
            type: 'string',
            enum: ['draft', 'booked', 'traveling', 'completed', 'cancelled'],
          },
          segments: {
            type: 'array',
            minItems: 1,
            items: { $ref: '#/components/schemas/NewFlightSegment' },
          },
        },
      },
      UpdateTravelItinerary: {
        allOf: [{ $ref: '#/components/schemas/NewTravelItinerary' }],
      },
      Group: {
        type: 'object',
        required: ['id', 'name', 'memberIds', 'itineraryIds', 'createdAt', 'updatedAt'],
        properties: {
          id: { type: 'string' },
          name: { type: 'string' },
          description: { type: 'string' },
          memberIds: { type: 'array', items: { type: 'string' } },
          itineraryIds: { type: 'array', items: { type: 'string' } },
          createdAt: { type: 'string', format: 'date-time' },
          updatedAt: { type: 'string', format: 'date-time' },
        },
      },
      NewGroup: {
        type: 'object',
        required: ['name'],
        properties: {
          name: { type: 'string' },
          description: { type: 'string' },
          memberIds: { type: 'array', items: { type: 'string' } },
          itineraryIds: { type: 'array', items: { type: 'string' } },
        },
      },
      UpdateGroup: {
        allOf: [{ $ref: '#/components/schemas/NewGroup' }],
      },
    },
    responses: {
      UnauthorizedError: {
        description: 'Missing or invalid API key',
        content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
      },
      NotFound: {
        description: 'Resource not found',
        content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
      },
      ValidationError: {
        description: 'Validation failed',
        content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
      },
      RateLimit: {
        description: 'Too many requests',
        headers: {
          'Retry-After': {
            schema: { type: 'integer' },
            description: 'Milliseconds to wait before retry',
          },
        },
        content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
      },
    },
  },
  security: [{ ApiKeyAuth: [] }],
  paths: {
    '/health': {
      get: {
        tags: ['Health'],
        security: [],
        summary: 'Health check',
        responses: {
          '200': {
            description: 'OK',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: { type: 'string' },
                    time: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
        },
      },
    },
    '/api/employees': {
      get: {
        tags: ['Employees'],
        summary: 'List employees',
        responses: {
          '200': {
            description: 'List',
            content: {
              'application/json': {
                schema: { type: 'array', items: { $ref: '#/components/schemas/Employee' } },
              },
            },
          },
          '401': { $ref: '#/components/responses/UnauthorizedError' },
        },
      },
      post: {
        tags: ['Employees'],
        summary: 'Create employee',
        requestBody: {
          required: true,
          content: { 'application/json': { schema: { $ref: '#/components/schemas/NewEmployee' } } },
        },
        responses: {
          '201': {
            description: 'Created',
            content: { 'application/json': { schema: { $ref: '#/components/schemas/Employee' } } },
          },
          '400': { $ref: '#/components/responses/ValidationError' },
          '401': { $ref: '#/components/responses/UnauthorizedError' },
        },
      },
    },
    '/api/employees/{id}': {
      get: {
        tags: ['Employees'],
        summary: 'Get employee',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          '200': {
            description: 'Employee',
            content: { 'application/json': { schema: { $ref: '#/components/schemas/Employee' } } },
          },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
      patch: {
        tags: ['Employees'],
        summary: 'Update employee',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          content: {
            'application/json': { schema: { $ref: '#/components/schemas/UpdateEmployee' } },
          },
        },
        responses: {
          '200': {
            description: 'Updated',
            content: { 'application/json': { schema: { $ref: '#/components/schemas/Employee' } } },
          },
          '400': { $ref: '#/components/responses/ValidationError' },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
      delete: {
        tags: ['Employees'],
        summary: 'Delete employee',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          '204': { description: 'Deleted' },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
    },
    '/api/employees/{id}/avatar': {
      get: {
        tags: ['Employees'],
        summary: 'Get employee avatar (custom upload or generated identicon)',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          '200': {
            description: 'Image',
            content: { 'image/svg+xml': {}, 'image/png': {}, 'image/jpeg': {}, 'image/webp': {} },
          },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
      post: {
        tags: ['Employees'],
        summary: 'Upload custom avatar for employee',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          required: true,
          content: {
            'multipart/form-data': {
              schema: {
                type: 'object',
                properties: {
                  file: { type: 'string', format: 'binary' },
                },
                required: ['file'],
              },
            },
          },
        },
        responses: {
          '201': {
            description: 'Uploaded',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: { message: { type: 'string' }, path: { type: 'string' } },
                },
              },
            },
          },
          '400': { $ref: '#/components/responses/ValidationError' },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
    },
    '/api/itineraries': {
      get: {
        tags: ['Itineraries'],
        summary: 'List itineraries (filterable)',
        parameters: [
          { name: 'employeeId', in: 'query', schema: { type: 'string' } },
          {
            name: 'status',
            in: 'query',
            schema: {
              type: 'string',
              enum: ['draft', 'booked', 'traveling', 'completed', 'cancelled'],
            },
          },
        ],
        responses: {
          '200': {
            description: 'List',
            content: {
              'application/json': {
                schema: { type: 'array', items: { $ref: '#/components/schemas/TravelItinerary' } },
              },
            },
          },
        },
      },
      post: {
        tags: ['Itineraries'],
        summary: 'Create itinerary',
        requestBody: {
          required: true,
          content: {
            'application/json': { schema: { $ref: '#/components/schemas/NewTravelItinerary' } },
          },
        },
        responses: {
          '201': {
            description: 'Created',
            content: {
              'application/json': { schema: { $ref: '#/components/schemas/TravelItinerary' } },
            },
          },
          '400': { $ref: '#/components/responses/ValidationError' },
        },
      },
    },
    '/api/itineraries/{id}': {
      get: {
        tags: ['Itineraries'],
        summary: 'Get itinerary',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          '200': {
            description: 'Itinerary',
            content: {
              'application/json': { schema: { $ref: '#/components/schemas/TravelItinerary' } },
            },
          },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
      patch: {
        tags: ['Itineraries'],
        summary: 'Update itinerary',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          content: {
            'application/json': { schema: { $ref: '#/components/schemas/UpdateTravelItinerary' } },
          },
        },
        responses: {
          '200': {
            description: 'Updated',
            content: {
              'application/json': { schema: { $ref: '#/components/schemas/TravelItinerary' } },
            },
          },
          '400': { $ref: '#/components/responses/ValidationError' },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
      delete: {
        tags: ['Itineraries'],
        summary: 'Delete itinerary',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          '204': { description: 'Deleted' },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
    },
    '/api/groups': {
      get: {
        tags: ['Groups'],
        summary: 'List groups',
        responses: {
          '200': {
            description: 'List',
            content: {
              'application/json': {
                schema: { type: 'array', items: { $ref: '#/components/schemas/Group' } },
              },
            },
          },
        },
      },
      post: {
        tags: ['Groups'],
        summary: 'Create group',
        requestBody: {
          required: true,
          content: { 'application/json': { schema: { $ref: '#/components/schemas/NewGroup' } } },
        },
        responses: {
          '201': {
            description: 'Created',
            content: { 'application/json': { schema: { $ref: '#/components/schemas/Group' } } },
          },
          '400': { $ref: '#/components/responses/ValidationError' },
        },
      },
    },
    '/api/groups/{id}': {
      get: {
        tags: ['Groups'],
        summary: 'Get group',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          '200': {
            description: 'Group',
            content: { 'application/json': { schema: { $ref: '#/components/schemas/Group' } } },
          },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
      patch: {
        tags: ['Groups'],
        summary: 'Update group',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          content: { 'application/json': { schema: { $ref: '#/components/schemas/UpdateGroup' } } },
        },
        responses: {
          '200': {
            description: 'Updated',
            content: { 'application/json': { schema: { $ref: '#/components/schemas/Group' } } },
          },
          '400': { $ref: '#/components/responses/ValidationError' },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
      delete: {
        tags: ['Groups'],
        summary: 'Delete group',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          '204': { description: 'Deleted' },
          '404': { $ref: '#/components/responses/NotFound' },
        },
      },
    },
  },
};
