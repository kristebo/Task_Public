## Flight Planner Backend (Case for Frontend-kandidat)

Dette er en enkel backend som simulerer et internt reiseplanleggingssystem for et mellomstort selskap. Domenet inkluderer tre kjerne-ressurser:

1. Employees – ansatte som kan reise.
2. Travel Itineraries – reiseplaner bestående av en eller flere flight-segmenter.
3. Groups – grupper av ansatte og tilknyttede itineraries (for felles reisenheter / prosjektreiser).

Data lagres fil-basert i `data/` katalogen for enkel testbarhet. Ingen database kreves.

Swagger/OpenAPI dokumentasjon er tilgjengelig på: `http://localhost:3000/docs`

### Teknologi

- Node.js + TypeScript
- Express
- Zod for validering
- Swagger UI for API-dokumentasjon
- Fil-basert lagring (JSON-filer)

### Kom i gang / Kjøring

Installer avhengigheter:

```bash
npm install
```

Utviklingsserver (fast API key `dev-key`):

```bash
npm run dev
```

Utviklingsserver med auto-generert API key (anbefalt for kandidat-testing):

```bash
npm run run-dev
```

Output viser generert nøkkel, eks:

```
[run-dev] Generated API key: dev-abc123xyz-q1w2e3r4
[run-dev] Use this header: x-api-key: dev-abc123xyz-q1w2e3r4
```

Bruk verdien i header: `x-api-key` for alle beskyttede endepunkter.

Kombinert sjekk (typecheck + tester) og start:

```bash
npm run runner
```

Produksjonsbuild:

```bash
npm run build
npm start
```

Server: `http://localhost:3000`

Du kan override nøkkel manuelt:

```bash
API_KEY=my-custom-key npm run dev
```

### Scripts oversikt

| Script           | Beskrivelse                                              |
| ---------------- | -------------------------------------------------------- |
| `dev`            | Starter dev-server (watch) med standard nøkkel `dev-key` |
| `run-dev`        | Genererer tilfeldig API key og starter server            |
| `runner`         | Typecheck + tester + dev-server                          |
| `check`          | Typecheck + tester                                       |
| `build`          | Transpilerer til `dist/`                                 |
| `start`          | Kjører bygget kode fra `dist/`                           |
| `start-frontend` | Starter Vite dev-server for frontend (port 5173)         |

### Frontend

Et grunnleggende React + Vite + Tailwind oppsett finnes i `frontend/` mappen.

Installer avhengigheter (fra rot):

```bash
cd frontend && npm install
```

Start frontend (fra rot):

```bash
npm run start-frontend
```

Eller inne i `frontend/`:

```bash
npm run dev
```

Frontend proxyer API-kall (`/api`, `/health`, `/docs`) til backend på `localhost:3000`.

I UI må du lime inn API key (generer via `npm run gen-key` eller bruk `dev-key`).

### Autentisering & Sikkerhet

Alle API-endepunkter under `/api/*` krever headeren:

```
x-api-key: <din-nøkkel>
```

Unntak: `/health` og `/docs` er åpne.

### Rate Limiting

En enkel IP-basert limiter er aktiv:
| Header | Forklaring |
|--------|-----------|
| `X-RateLimit-Limit` | Maks antall forespørsler per vindu |
| `X-RateLimit-Remaining` | Gjenværende i nåværende vindu |
| `X-RateLimit-Reset` | ISO-tidspunkt når vinduet nullstilles |

Ved overskridelse: HTTP 429 med kropp:

```json
{ "error": { "code": "RATE_LIMIT", "message": "Too many requests", "retryAfterMs": 12345 } }
```

### Feilformat

Alle feil følger strukturen:

```json
{
  "error": {
    "code": "VALIDATION",
    "message": "Validation failed",
    "details": [{ "path": ["firstName"], "message": "Required" }]
  }
}
```

Eksempler på `code`:
| Code | Situasjon |
|------|-----------|
| `UNAUTHORIZED` | Manglende / feil API key |
| `VALIDATION` | Zod valideringsfeil |
| `NOT_FOUND` | Ressurs finnes ikke |
| `REF_INTEGRITY` | Brudd på referanse (f.eks. ukjent employeeId) |
| `RATE_LIMIT` | For mange forespørsler |

### Teste lokalt (eksempel med curl)

```bash
API_KEY=$(node -e "console.log('dev-key')")
curl -H "x-api-key: $API_KEY" http://localhost:3000/api/employees
```

Opprett employee:

```bash
curl -X POST -H "Content-Type: application/json" -H "x-api-key: $API_KEY" \
  -d '{"firstName":"Anna","lastName":"Aasen","email":"anna@example.com","department":"Engineering","title":"Developer"}' \
  http://localhost:3000/api/employees
```

### Domenemodell

```mermaid
classDiagram
  class Employee {
    id
    firstName
    lastName
    email
    department
    title
    active
  }
  class TravelItinerary {
    id
    employeeId
    purpose
    status
    segments[]
  }
  class FlightSegment {
    id
    from
    to
    departure
    arrival
    carrier
    flightNumber
    seatClass
  }
  class Group {
    id
    name
    memberIds[]
    itineraryIds[]
  }
  Employee <|-- TravelItinerary : employeeId
  Group o-- Employee : memberIds
  Group o-- TravelItinerary : itineraryIds
```

### Ressurser & Endepunkter

Alla endepunkter beskrives i Swagger (`/docs`). Kort oversikt:

| Resource    | Endepunkter                                                                                                                                                               |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Health      | `GET /health`                                                                                                                                                             |
| Employees   | `GET /api/employees`, `GET /api/employees/:id`, `POST /api/employees`, `PATCH /api/employees/:id`, `DELETE /api/employees/:id`                                            |
| Itineraries | `GET /api/itineraries` (filter: `employeeId`, `status`), `GET /api/itineraries/:id`, `POST /api/itineraries`, `PATCH /api/itineraries/:id`, `DELETE /api/itineraries/:id` |
| Groups      | `GET /api/groups`, `GET /api/groups/:id`, `POST /api/groups`, `PATCH /api/groups/:id`, `DELETE /api/groups/:id`                                                           |

### Datavalidering (utdrag)

Employee (create):

```json
{
  "firstName": "Anna",
  "lastName": "Aasen",
  "email": "anna@example.com",
  "department": "Engineering",
  "title": "Developer"
}
```

Itinerary (create):

```json
{
  "employeeId": "emp1",
  "purpose": "Kundemøte i Stockholm",
  "segments": [
    {
      "from": "OSL",
      "to": "ARN",
      "departure": "2025-10-01T07:30:00Z",
      "arrival": "2025-10-01T08:25:00Z",
      "carrier": "SK",
      "flightNumber": "SK894",
      "seatClass": "economy"
    }
  ]
}
```

### Oppgave til frontend-kandidat

Lag en liten webklient som gir et oversiktlig grensesnitt for dette domenet.

Minimum:

1. Liste ansatte (navn, avdeling, aktiv status) + søk/filter (department, tekstsøk på navn).
2. Detaljside for ansatt: viser itineraries tilknyttet ansatte + kan opprette ny itinerary.
3. Opprette / redigere / slette itinerary med flere flight-segmenter (UI for å legge til segmentlinjer dynamisk).
4. Vise grupper og deres medlemmer samt lenke til itinerary-oversikt.
5. Opprette ny gruppe ved å velge eksisterende employees og itineraries (multi-select).
6. Validerings- og feiltilstander i UI (f.eks. hvis employeeId mangler ved oppretting av itinerary).

Bonus (valgfritt):

- Optimistic updates.
- Drag & drop rekkefølge på flight-segmenter.
- Statusindikator (fargechip) for itinerary status.
- Bulk-endringer (aktiver/deaktiver flere ansatte).
- Dashboard med nøkkeltall (antall aktive ansatte, itineraries per status, mest brukte ruter (from→to)).
- Enkel caching/state management (React Query el.l.).
- Test av én kritisk hook/komponent.
- aria og UU

Vurderingskriterier:

- Kodearkitektur og modularitet
- UX (oversiktlighet, konsistens, tilbakemeldinger)
- Dataflyt og asynkron håndtering
- Edge cases (ingen data, loading, feil)

### Forslag til videre forbedringer (ikke implementert)

- Autentisering (JWT / OIDC)
- RBAC (rollebasert tilgang)
- Revisjonslogg av endringer
- Rate limiting og caching-headere
- Database + migreringer
- Notifikasjoner / webhooks ved endringer

### Swagger

Se `http://localhost:3000/docs` for auto-generert dokumentasjon.

Lykke til! ✈️
